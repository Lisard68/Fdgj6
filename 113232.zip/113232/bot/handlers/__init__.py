from bot.handlers import admin
from bot.handlers import game
from bot.handlers import mines
from bot.handlers import cmds
from bot.handlers import profile