#КЭФЫ

DICE = 1.8 #ЧЕТ НЕЧЕТ КУБ
DICE_MORE_LESS = 1.8#БОЛЬШЕ МЕНЬШЕ
DICE_NUMBER = 4 #ЧИСЛО
DUEL = 1.8 #ДУЭЛЬ
DARTS = 4 #ДАРТС
DARTS_COLOR = 1.8 #ДАРТС КРАСН/БЕЛ
BASKET = 1.8 #БАСКЕТ
BASKET_MISS = 1.25 #БАСКЕТ МИМО
FOOTBALL = 1.25 #ФУТБОЛ
FOOTBALL_MISS = 1.8#ФУТБОЛ МИМО
BOWLING = 4 #БОУЛИНГ
SLOTS_777 = 10 #СЛОТЫ 777
SLOTS_GRAPE = 5 #СЛОТЫ ВИНОГРАД
SLOTS_BAR = 5 #СЛОТЫ БАР
SLOTS_LEMON = 5 #СЛОТЫ ЛИМОН
KNB = 1.8 #КАМЕНЬ НОЖНИЦЫ БУМАГА
