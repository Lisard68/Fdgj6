TOKEN = "7195375816:AAFSWvSGR5XsDGfYFf7TslULLJnC1vWbxLg" #токен BotFather
CRYPTO_TOKEN = "189781:AALiOEuPP7Ij02CNRUTLDbHYppHvemAylve" #токен CreptoPay
LOG_CHANNEL = -1002132351037 #ЛОГИРОВАНИЕ
CHANNEL_BROKER = -1002083718487 #Посредник
MAIN_CHANNEL = -1002083718487 #основа
ADMINS = [ 6470001380 ] #список админов
CHECK_URL = "t.me/send?start=IVTXFU18RkWg" #юрл счёта
MONEYBACK = 0 #процент манибэка от игры
